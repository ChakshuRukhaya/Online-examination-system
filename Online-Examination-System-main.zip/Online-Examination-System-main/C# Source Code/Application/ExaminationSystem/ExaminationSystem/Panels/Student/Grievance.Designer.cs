

namespace ExaminationSystem.Panels.Student
{
    partial class Grievance
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Question10txt = new RichTextBox();
            QuestionTextLabel10 = new Label();
            correctAnsLabel10 = new Label();
            studentAns10 = new TextBox();
            correctAns10 = new TextBox();
            yourAnsLabel10 = new Label();
            Question9txt = new RichTextBox();
            QuestionTextLabel9 = new Label();
            correctAnsLabel9 = new Label();
            studentAns9 = new TextBox();
            correctAns9 = new TextBox();
            yourAnsLabel9 = new Label();
            Question8txt = new RichTextBox();
            QuestionTextLabel8 = new Label();
            correctAnsLabel8 = new Label();
            studentAns8 = new TextBox();
            correctAns8 = new TextBox();
            yourAnsLabel8 = new Label();
            Question7txt = new RichTextBox();
            QuestionTextLabel7 = new Label();
            correctAnsLabel7 = new Label();
            studentAns7 = new TextBox();
            correctAns7 = new TextBox();
            yourAnsLabel7 = new Label();
            Question6txt = new RichTextBox();
            QuestionTextLabel6 = new Label();
            correctAnsLabel6 = new Label();
            studentAns6 = new TextBox();
            correctAns6 = new TextBox();
            yourAnsLabel6 = new Label();
            Question3txt = new RichTextBox();
            QuestionTextLabel3 = new Label();
            correctAnsLabel3 = new Label();
            studentAns3 = new TextBox();
            correctAns3 = new TextBox();
            yourAnsLabel3 = new Label();
            Question5txt = new RichTextBox();
            QuestionTextLabel5 = new Label();
            correctAnsLabel5 = new Label();
            studentAns5 = new TextBox();
            correctAns5 = new TextBox();
            yourAnsLabel5 = new Label();
            Question4txt = new RichTextBox();
            QuestionTextLabel4 = new Label();
            correctAnsLabel4 = new Label();
            studentAns4 = new TextBox();
            correctAns4 = new TextBox();
            yourAnsLabel4 = new Label();
            Question2txt = new RichTextBox();
            QuestionTextLabel2 = new Label();
            correctAnsLabel2 = new Label();
            studentAns2 = new TextBox();
            correctAns2 = new TextBox();
            yourAnsLabel2 = new Label();
            Question1txt = new RichTextBox();
            QuestionTextLabel1 = new Label();
            ShowGrievance = new Button();
            CourseComboBox = new ComboBox();
            CourseName = new Label();
            label1 = new Label();
            correctAnsLabel1 = new Label();
            studentAns1 = new TextBox();
            correctAns1 = new TextBox();
            yourAnsLabel1 = new Label();
            GrievancePanel = new Panel();
            Title = new Label();
            panel1.SuspendLayout();
            GrievancePanel.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.Controls.Add(Question10txt);
            panel1.Controls.Add(QuestionTextLabel10);
            panel1.Controls.Add(correctAnsLabel10);
            panel1.Controls.Add(studentAns10);
            panel1.Controls.Add(correctAns10);
            panel1.Controls.Add(yourAnsLabel10);
            panel1.Controls.Add(Question9txt);
            panel1.Controls.Add(QuestionTextLabel9);
            panel1.Controls.Add(correctAnsLabel9);
            panel1.Controls.Add(studentAns9);
            panel1.Controls.Add(correctAns9);
            panel1.Controls.Add(yourAnsLabel9);
            panel1.Controls.Add(Question8txt);
            panel1.Controls.Add(QuestionTextLabel8);
            panel1.Controls.Add(correctAnsLabel8);
            panel1.Controls.Add(studentAns8);
            panel1.Controls.Add(correctAns8);
            panel1.Controls.Add(yourAnsLabel8);
            panel1.Controls.Add(Question7txt);
            panel1.Controls.Add(QuestionTextLabel7);
            panel1.Controls.Add(correctAnsLabel7);
            panel1.Controls.Add(studentAns7);
            panel1.Controls.Add(correctAns7);
            panel1.Controls.Add(yourAnsLabel7);
            panel1.Controls.Add(Question6txt);
            panel1.Controls.Add(QuestionTextLabel6);
            panel1.Controls.Add(correctAnsLabel6);
            panel1.Controls.Add(studentAns6);
            panel1.Controls.Add(correctAns6);
            panel1.Controls.Add(yourAnsLabel6);
            panel1.Controls.Add(Question3txt);
            panel1.Controls.Add(QuestionTextLabel3);
            panel1.Controls.Add(correctAnsLabel3);
            panel1.Controls.Add(studentAns3);
            panel1.Controls.Add(correctAns3);
            panel1.Controls.Add(yourAnsLabel3);
            panel1.Controls.Add(Question5txt);
            panel1.Controls.Add(QuestionTextLabel5);
            panel1.Controls.Add(correctAnsLabel5);
            panel1.Controls.Add(studentAns5);
            panel1.Controls.Add(correctAns5);
            panel1.Controls.Add(yourAnsLabel5);
            panel1.Controls.Add(Question4txt);
            panel1.Controls.Add(QuestionTextLabel4);
            panel1.Controls.Add(correctAnsLabel4);
            panel1.Controls.Add(studentAns4);
            panel1.Controls.Add(correctAns4);
            panel1.Controls.Add(yourAnsLabel4);
            panel1.Controls.Add(Question2txt);
            panel1.Controls.Add(QuestionTextLabel2);
            panel1.Controls.Add(correctAnsLabel2);
            panel1.Controls.Add(studentAns2);
            panel1.Controls.Add(correctAns2);
            panel1.Controls.Add(yourAnsLabel2);
            panel1.Controls.Add(Question1txt);
            panel1.Controls.Add(QuestionTextLabel1);
            panel1.Controls.Add(ShowGrievance);
            panel1.Controls.Add(CourseComboBox);
            panel1.Controls.Add(CourseName);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(correctAnsLabel1);
            panel1.Controls.Add(studentAns1);
            panel1.Controls.Add(correctAns1);
            panel1.Controls.Add(yourAnsLabel1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(930, 1338);
            panel1.TabIndex = 0;
            // 
            // Question10txt
            // 
            Question10txt.Anchor = AnchorStyles.Top;
            Question10txt.BorderStyle = BorderStyle.None;
            Question10txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question10txt.Location = new Point(23, 1045);
            Question10txt.Name = "Question10txt";
            Question10txt.Size = new Size(219, 108);
            Question10txt.TabIndex = 142;
            Question10txt.Text = "";
            // 
            // QuestionTextLabel10
            // 
            QuestionTextLabel10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel10.AutoSize = true;
            QuestionTextLabel10.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel10.Location = new Point(23, 1012);
            QuestionTextLabel10.MaximumSize = new Size(0, 30);
            QuestionTextLabel10.MinimumSize = new Size(0, 30);
            QuestionTextLabel10.Name = "QuestionTextLabel10";
            QuestionTextLabel10.Size = new Size(150, 30);
            QuestionTextLabel10.TabIndex = 141;
            QuestionTextLabel10.Text = "Question Text";
            // 
            // correctAnsLabel10
            // 
            correctAnsLabel10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel10.AutoSize = true;
            correctAnsLabel10.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel10.Location = new Point(23, 1166);
            correctAnsLabel10.MaximumSize = new Size(0, 30);
            correctAnsLabel10.MinimumSize = new Size(0, 30);
            correctAnsLabel10.Name = "correctAnsLabel10";
            correctAnsLabel10.Size = new Size(164, 30);
            correctAnsLabel10.TabIndex = 140;
            correctAnsLabel10.Text = "Correct answer";
            // 
            // studentAns10
            // 
            studentAns10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns10.BackColor = Color.White;
            studentAns10.BorderStyle = BorderStyle.None;
            studentAns10.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns10.Location = new Point(22, 1265);
            studentAns10.MaximumSize = new Size(250, 30);
            studentAns10.MinimumSize = new Size(250, 30);
            studentAns10.Name = "studentAns10";
            studentAns10.Size = new Size(250, 30);
            studentAns10.TabIndex = 137;
            // 
            // correctAns10
            // 
            correctAns10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns10.BackColor = Color.White;
            correctAns10.BorderStyle = BorderStyle.None;
            correctAns10.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns10.Location = new Point(23, 1199);
            correctAns10.MaximumSize = new Size(250, 30);
            correctAns10.MinimumSize = new Size(250, 30);
            correctAns10.Name = "correctAns10";
            correctAns10.Size = new Size(250, 30);
            correctAns10.TabIndex = 138;
            // 
            // yourAnsLabel10
            // 
            yourAnsLabel10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel10.AutoSize = true;
            yourAnsLabel10.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel10.Location = new Point(22, 1232);
            yourAnsLabel10.MaximumSize = new Size(0, 30);
            yourAnsLabel10.MinimumSize = new Size(0, 30);
            yourAnsLabel10.Name = "yourAnsLabel10";
            yourAnsLabel10.Size = new Size(136, 30);
            yourAnsLabel10.TabIndex = 139;
            yourAnsLabel10.Text = "Your answer";
            // 
            // Question9txt
            // 
            Question9txt.Anchor = AnchorStyles.Top;
            Question9txt.BorderStyle = BorderStyle.None;
            Question9txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question9txt.Location = new Point(591, 747);
            Question9txt.Name = "Question9txt";
            Question9txt.Size = new Size(219, 108);
            Question9txt.TabIndex = 136;
            Question9txt.Text = "";
            // 
            // QuestionTextLabel9
            // 
            QuestionTextLabel9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel9.AutoSize = true;
            QuestionTextLabel9.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel9.Location = new Point(591, 714);
            QuestionTextLabel9.MaximumSize = new Size(0, 30);
            QuestionTextLabel9.MinimumSize = new Size(0, 30);
            QuestionTextLabel9.Name = "QuestionTextLabel9";
            QuestionTextLabel9.Size = new Size(150, 30);
            QuestionTextLabel9.TabIndex = 135;
            QuestionTextLabel9.Text = "Question Text";
            // 
            // correctAnsLabel9
            // 
            correctAnsLabel9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel9.AutoSize = true;
            correctAnsLabel9.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel9.Location = new Point(591, 868);
            correctAnsLabel9.MaximumSize = new Size(0, 30);
            correctAnsLabel9.MinimumSize = new Size(0, 30);
            correctAnsLabel9.Name = "correctAnsLabel9";
            correctAnsLabel9.Size = new Size(164, 30);
            correctAnsLabel9.TabIndex = 134;
            correctAnsLabel9.Text = "Correct answer";
            // 
            // studentAns9
            // 
            studentAns9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns9.BackColor = Color.White;
            studentAns9.BorderStyle = BorderStyle.None;
            studentAns9.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns9.Location = new Point(591, 967);
            studentAns9.MaximumSize = new Size(250, 30);
            studentAns9.MinimumSize = new Size(250, 30);
            studentAns9.Name = "studentAns9";
            studentAns9.Size = new Size(250, 30);
            studentAns9.TabIndex = 131;
            // 
            // correctAns9
            // 
            correctAns9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns9.BackColor = Color.White;
            correctAns9.BorderStyle = BorderStyle.None;
            correctAns9.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns9.Location = new Point(591, 901);
            correctAns9.MaximumSize = new Size(250, 30);
            correctAns9.MinimumSize = new Size(250, 30);
            correctAns9.Name = "correctAns9";
            correctAns9.Size = new Size(250, 30);
            correctAns9.TabIndex = 132;
            // 
            // yourAnsLabel9
            // 
            yourAnsLabel9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel9.AutoSize = true;
            yourAnsLabel9.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel9.Location = new Point(591, 934);
            yourAnsLabel9.MaximumSize = new Size(0, 30);
            yourAnsLabel9.MinimumSize = new Size(0, 30);
            yourAnsLabel9.Name = "yourAnsLabel9";
            yourAnsLabel9.Size = new Size(136, 30);
            yourAnsLabel9.TabIndex = 133;
            yourAnsLabel9.Text = "Your answer";
            yourAnsLabel9.Click += label4_Click;
            // 
            // Question8txt
            // 
            Question8txt.Anchor = AnchorStyles.Top;
            Question8txt.BorderStyle = BorderStyle.None;
            Question8txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question8txt.Location = new Point(317, 747);
            Question8txt.Name = "Question8txt";
            Question8txt.Size = new Size(219, 108);
            Question8txt.TabIndex = 130;
            Question8txt.Text = "";
            // 
            // QuestionTextLabel8
            // 
            QuestionTextLabel8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel8.AutoSize = true;
            QuestionTextLabel8.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel8.Location = new Point(317, 714);
            QuestionTextLabel8.MaximumSize = new Size(0, 30);
            QuestionTextLabel8.MinimumSize = new Size(0, 30);
            QuestionTextLabel8.Name = "QuestionTextLabel8";
            QuestionTextLabel8.Size = new Size(150, 30);
            QuestionTextLabel8.TabIndex = 129;
            QuestionTextLabel8.Text = "Question Text";
            // 
            // correctAnsLabel8
            // 
            correctAnsLabel8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel8.AutoSize = true;
            correctAnsLabel8.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel8.Location = new Point(317, 868);
            correctAnsLabel8.MaximumSize = new Size(0, 30);
            correctAnsLabel8.MinimumSize = new Size(0, 30);
            correctAnsLabel8.Name = "correctAnsLabel8";
            correctAnsLabel8.Size = new Size(164, 30);
            correctAnsLabel8.TabIndex = 128;
            correctAnsLabel8.Text = "Correct answer";
            // 
            // studentAns8
            // 
            studentAns8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns8.BackColor = Color.White;
            studentAns8.BorderStyle = BorderStyle.None;
            studentAns8.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns8.Location = new Point(316, 967);
            studentAns8.MaximumSize = new Size(250, 30);
            studentAns8.MinimumSize = new Size(250, 30);
            studentAns8.Name = "studentAns8";
            studentAns8.Size = new Size(250, 30);
            studentAns8.TabIndex = 125;
            // 
            // correctAns8
            // 
            correctAns8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns8.BackColor = Color.White;
            correctAns8.BorderStyle = BorderStyle.None;
            correctAns8.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns8.Location = new Point(317, 901);
            correctAns8.MaximumSize = new Size(250, 30);
            correctAns8.MinimumSize = new Size(250, 30);
            correctAns8.Name = "correctAns8";
            correctAns8.Size = new Size(250, 30);
            correctAns8.TabIndex = 126;
            // 
            // yourAnsLabel8
            // 
            yourAnsLabel8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel8.AutoSize = true;
            yourAnsLabel8.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel8.Location = new Point(316, 934);
            yourAnsLabel8.MaximumSize = new Size(0, 30);
            yourAnsLabel8.MinimumSize = new Size(0, 30);
            yourAnsLabel8.Name = "yourAnsLabel8";
            yourAnsLabel8.Size = new Size(136, 30);
            yourAnsLabel8.TabIndex = 127;
            yourAnsLabel8.Text = "Your answer";
            // 
            // Question7txt
            // 
            Question7txt.Anchor = AnchorStyles.Top;
            Question7txt.BorderStyle = BorderStyle.None;
            Question7txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question7txt.Location = new Point(23, 747);
            Question7txt.Name = "Question7txt";
            Question7txt.Size = new Size(219, 108);
            Question7txt.TabIndex = 124;
            Question7txt.Text = "";
            // 
            // QuestionTextLabel7
            // 
            QuestionTextLabel7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel7.AutoSize = true;
            QuestionTextLabel7.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel7.Location = new Point(23, 714);
            QuestionTextLabel7.MaximumSize = new Size(0, 30);
            QuestionTextLabel7.MinimumSize = new Size(0, 30);
            QuestionTextLabel7.Name = "QuestionTextLabel7";
            QuestionTextLabel7.Size = new Size(150, 30);
            QuestionTextLabel7.TabIndex = 123;
            QuestionTextLabel7.Text = "Question Text";
            QuestionTextLabel7.Click += label8_Click_1;
            // 
            // correctAnsLabel7
            // 
            correctAnsLabel7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel7.AutoSize = true;
            correctAnsLabel7.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel7.Location = new Point(23, 868);
            correctAnsLabel7.MaximumSize = new Size(0, 30);
            correctAnsLabel7.MinimumSize = new Size(0, 30);
            correctAnsLabel7.Name = "correctAnsLabel7";
            correctAnsLabel7.Size = new Size(164, 30);
            correctAnsLabel7.TabIndex = 122;
            correctAnsLabel7.Text = "Correct answer";
            // 
            // studentAns7
            // 
            studentAns7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns7.BackColor = Color.White;
            studentAns7.BorderStyle = BorderStyle.None;
            studentAns7.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns7.Location = new Point(23, 967);
            studentAns7.MaximumSize = new Size(250, 30);
            studentAns7.MinimumSize = new Size(250, 30);
            studentAns7.Name = "studentAns7";
            studentAns7.Size = new Size(250, 30);
            studentAns7.TabIndex = 119;
            // 
            // correctAns7
            // 
            correctAns7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns7.BackColor = Color.White;
            correctAns7.BorderStyle = BorderStyle.None;
            correctAns7.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns7.Location = new Point(23, 901);
            correctAns7.MaximumSize = new Size(250, 30);
            correctAns7.MinimumSize = new Size(250, 30);
            correctAns7.Name = "correctAns7";
            correctAns7.Size = new Size(250, 30);
            correctAns7.TabIndex = 120;
            // 
            // yourAnsLabel7
            // 
            yourAnsLabel7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel7.AutoSize = true;
            yourAnsLabel7.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel7.Location = new Point(23, 934);
            yourAnsLabel7.MaximumSize = new Size(0, 30);
            yourAnsLabel7.MinimumSize = new Size(0, 30);
            yourAnsLabel7.Name = "yourAnsLabel7";
            yourAnsLabel7.Size = new Size(136, 30);
            yourAnsLabel7.TabIndex = 121;
            yourAnsLabel7.Text = "Your answer";
            // 
            // Question6txt
            // 
            Question6txt.Anchor = AnchorStyles.Top;
            Question6txt.BorderStyle = BorderStyle.None;
            Question6txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question6txt.Location = new Point(591, 448);
            Question6txt.Name = "Question6txt";
            Question6txt.Size = new Size(219, 108);
            Question6txt.TabIndex = 118;
            Question6txt.Text = "";
            // 
            // QuestionTextLabel6
            // 
            QuestionTextLabel6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel6.AutoSize = true;
            QuestionTextLabel6.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel6.Location = new Point(591, 415);
            QuestionTextLabel6.MaximumSize = new Size(0, 30);
            QuestionTextLabel6.MinimumSize = new Size(0, 30);
            QuestionTextLabel6.Name = "QuestionTextLabel6";
            QuestionTextLabel6.Size = new Size(150, 30);
            QuestionTextLabel6.TabIndex = 117;
            QuestionTextLabel6.Text = "Question Text";
            // 
            // correctAnsLabel6
            // 
            correctAnsLabel6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel6.AutoSize = true;
            correctAnsLabel6.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel6.Location = new Point(591, 569);
            correctAnsLabel6.MaximumSize = new Size(0, 30);
            correctAnsLabel6.MinimumSize = new Size(0, 30);
            correctAnsLabel6.Name = "correctAnsLabel6";
            correctAnsLabel6.Size = new Size(164, 30);
            correctAnsLabel6.TabIndex = 116;
            correctAnsLabel6.Text = "Correct answer";
            // 
            // studentAns6
            // 
            studentAns6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns6.BackColor = Color.White;
            studentAns6.BorderStyle = BorderStyle.None;
            studentAns6.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns6.Location = new Point(591, 668);
            studentAns6.MaximumSize = new Size(250, 30);
            studentAns6.MinimumSize = new Size(250, 30);
            studentAns6.Name = "studentAns6";
            studentAns6.Size = new Size(250, 30);
            studentAns6.TabIndex = 113;
            // 
            // correctAns6
            // 
            correctAns6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns6.BackColor = Color.White;
            correctAns6.BorderStyle = BorderStyle.None;
            correctAns6.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns6.Location = new Point(591, 602);
            correctAns6.MaximumSize = new Size(250, 30);
            correctAns6.MinimumSize = new Size(250, 30);
            correctAns6.Name = "correctAns6";
            correctAns6.Size = new Size(250, 30);
            correctAns6.TabIndex = 114;
            // 
            // yourAnsLabel6
            // 
            yourAnsLabel6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel6.AutoSize = true;
            yourAnsLabel6.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel6.Location = new Point(591, 635);
            yourAnsLabel6.MaximumSize = new Size(0, 30);
            yourAnsLabel6.MinimumSize = new Size(0, 30);
            yourAnsLabel6.Name = "yourAnsLabel6";
            yourAnsLabel6.Size = new Size(136, 30);
            yourAnsLabel6.TabIndex = 115;
            yourAnsLabel6.Text = "Your answer";
            // 
            // Question3txt
            // 
            Question3txt.Anchor = AnchorStyles.Top;
            Question3txt.BorderStyle = BorderStyle.None;
            Question3txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question3txt.Location = new Point(591, 152);
            Question3txt.Name = "Question3txt";
            Question3txt.Size = new Size(219, 108);
            Question3txt.TabIndex = 112;
            Question3txt.Text = "";
            // 
            // QuestionTextLabel3
            // 
            QuestionTextLabel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel3.AutoSize = true;
            QuestionTextLabel3.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel3.Location = new Point(591, 119);
            QuestionTextLabel3.MaximumSize = new Size(0, 30);
            QuestionTextLabel3.MinimumSize = new Size(0, 30);
            QuestionTextLabel3.Name = "QuestionTextLabel3";
            QuestionTextLabel3.Size = new Size(150, 30);
            QuestionTextLabel3.TabIndex = 111;
            QuestionTextLabel3.Text = "Question Text";
            // 
            // correctAnsLabel3
            // 
            correctAnsLabel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel3.AutoSize = true;
            correctAnsLabel3.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel3.Location = new Point(591, 273);
            correctAnsLabel3.MaximumSize = new Size(0, 30);
            correctAnsLabel3.MinimumSize = new Size(0, 30);
            correctAnsLabel3.Name = "correctAnsLabel3";
            correctAnsLabel3.Size = new Size(164, 30);
            correctAnsLabel3.TabIndex = 110;
            correctAnsLabel3.Text = "Correct answer";
            // 
            // studentAns3
            // 
            studentAns3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns3.BackColor = Color.White;
            studentAns3.BorderStyle = BorderStyle.None;
            studentAns3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns3.Location = new Point(591, 372);
            studentAns3.MaximumSize = new Size(250, 30);
            studentAns3.MinimumSize = new Size(250, 30);
            studentAns3.Name = "studentAns3";
            studentAns3.Size = new Size(250, 30);
            studentAns3.TabIndex = 107;
            // 
            // correctAns3
            // 
            correctAns3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns3.BackColor = Color.White;
            correctAns3.BorderStyle = BorderStyle.None;
            correctAns3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns3.Location = new Point(591, 306);
            correctAns3.MaximumSize = new Size(250, 30);
            correctAns3.MinimumSize = new Size(250, 30);
            correctAns3.Name = "correctAns3";
            correctAns3.Size = new Size(250, 30);
            correctAns3.TabIndex = 108;
            // 
            // yourAnsLabel3
            // 
            yourAnsLabel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel3.AutoSize = true;
            yourAnsLabel3.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel3.Location = new Point(591, 339);
            yourAnsLabel3.MaximumSize = new Size(0, 30);
            yourAnsLabel3.MinimumSize = new Size(0, 30);
            yourAnsLabel3.Name = "yourAnsLabel3";
            yourAnsLabel3.Size = new Size(136, 30);
            yourAnsLabel3.TabIndex = 109;
            yourAnsLabel3.Text = "Your answer";
            // 
            // Question5txt
            // 
            Question5txt.Anchor = AnchorStyles.Top;
            Question5txt.BorderStyle = BorderStyle.None;
            Question5txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question5txt.Location = new Point(317, 448);
            Question5txt.Name = "Question5txt";
            Question5txt.Size = new Size(219, 108);
            Question5txt.TabIndex = 106;
            Question5txt.Text = "";
            // 
            // QuestionTextLabel5
            // 
            QuestionTextLabel5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel5.AutoSize = true;
            QuestionTextLabel5.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel5.Location = new Point(317, 415);
            QuestionTextLabel5.MaximumSize = new Size(0, 30);
            QuestionTextLabel5.MinimumSize = new Size(0, 30);
            QuestionTextLabel5.Name = "QuestionTextLabel5";
            QuestionTextLabel5.Size = new Size(150, 30);
            QuestionTextLabel5.TabIndex = 105;
            QuestionTextLabel5.Text = "Question Text";
            // 
            // correctAnsLabel5
            // 
            correctAnsLabel5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel5.AutoSize = true;
            correctAnsLabel5.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel5.Location = new Point(317, 569);
            correctAnsLabel5.MaximumSize = new Size(0, 30);
            correctAnsLabel5.MinimumSize = new Size(0, 30);
            correctAnsLabel5.Name = "correctAnsLabel5";
            correctAnsLabel5.Size = new Size(164, 30);
            correctAnsLabel5.TabIndex = 104;
            correctAnsLabel5.Text = "Correct answer";
            correctAnsLabel5.Click += label8_Click;
            // 
            // studentAns5
            // 
            studentAns5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns5.BackColor = Color.White;
            studentAns5.BorderStyle = BorderStyle.None;
            studentAns5.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns5.Location = new Point(316, 668);
            studentAns5.MaximumSize = new Size(250, 30);
            studentAns5.MinimumSize = new Size(250, 30);
            studentAns5.Name = "studentAns5";
            studentAns5.Size = new Size(250, 30);
            studentAns5.TabIndex = 101;
            // 
            // correctAns5
            // 
            correctAns5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns5.BackColor = Color.White;
            correctAns5.BorderStyle = BorderStyle.None;
            correctAns5.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns5.Location = new Point(317, 602);
            correctAns5.MaximumSize = new Size(250, 30);
            correctAns5.MinimumSize = new Size(250, 30);
            correctAns5.Name = "correctAns5";
            correctAns5.Size = new Size(250, 30);
            correctAns5.TabIndex = 102;
            // 
            // yourAnsLabel5
            // 
            yourAnsLabel5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel5.AutoSize = true;
            yourAnsLabel5.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel5.Location = new Point(316, 635);
            yourAnsLabel5.MaximumSize = new Size(0, 30);
            yourAnsLabel5.MinimumSize = new Size(0, 30);
            yourAnsLabel5.Name = "yourAnsLabel5";
            yourAnsLabel5.Size = new Size(136, 30);
            yourAnsLabel5.TabIndex = 103;
            yourAnsLabel5.Text = "Your answer";
            // 
            // Question4txt
            // 
            Question4txt.Anchor = AnchorStyles.Top;
            Question4txt.BorderStyle = BorderStyle.None;
            Question4txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question4txt.Location = new Point(23, 448);
            Question4txt.Name = "Question4txt";
            Question4txt.Size = new Size(219, 108);
            Question4txt.TabIndex = 100;
            Question4txt.Text = "";
            // 
            // QuestionTextLabel4
            // 
            QuestionTextLabel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel4.AutoSize = true;
            QuestionTextLabel4.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel4.Location = new Point(23, 415);
            QuestionTextLabel4.MaximumSize = new Size(0, 30);
            QuestionTextLabel4.MinimumSize = new Size(0, 30);
            QuestionTextLabel4.Name = "QuestionTextLabel4";
            QuestionTextLabel4.Size = new Size(150, 30);
            QuestionTextLabel4.TabIndex = 99;
            QuestionTextLabel4.Text = "Question Text";
            // 
            // correctAnsLabel4
            // 
            correctAnsLabel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel4.AutoSize = true;
            correctAnsLabel4.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel4.Location = new Point(23, 569);
            correctAnsLabel4.MaximumSize = new Size(0, 30);
            correctAnsLabel4.MinimumSize = new Size(0, 30);
            correctAnsLabel4.Name = "correctAnsLabel4";
            correctAnsLabel4.Size = new Size(164, 30);
            correctAnsLabel4.TabIndex = 98;
            correctAnsLabel4.Text = "Correct answer";
            // 
            // studentAns4
            // 
            studentAns4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns4.BackColor = Color.White;
            studentAns4.BorderStyle = BorderStyle.None;
            studentAns4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns4.Location = new Point(23, 668);
            studentAns4.MaximumSize = new Size(250, 30);
            studentAns4.MinimumSize = new Size(250, 30);
            studentAns4.Name = "studentAns4";
            studentAns4.Size = new Size(250, 30);
            studentAns4.TabIndex = 95;
            // 
            // correctAns4
            // 
            correctAns4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns4.BackColor = Color.White;
            correctAns4.BorderStyle = BorderStyle.None;
            correctAns4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns4.Location = new Point(23, 602);
            correctAns4.MaximumSize = new Size(250, 30);
            correctAns4.MinimumSize = new Size(250, 30);
            correctAns4.Name = "correctAns4";
            correctAns4.Size = new Size(250, 30);
            correctAns4.TabIndex = 96;
            // 
            // yourAnsLabel4
            // 
            yourAnsLabel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel4.AutoSize = true;
            yourAnsLabel4.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel4.Location = new Point(23, 635);
            yourAnsLabel4.MaximumSize = new Size(0, 30);
            yourAnsLabel4.MinimumSize = new Size(0, 30);
            yourAnsLabel4.Name = "yourAnsLabel4";
            yourAnsLabel4.Size = new Size(136, 30);
            yourAnsLabel4.TabIndex = 97;
            yourAnsLabel4.Text = "Your answer";
            // 
            // Question2txt
            // 
            Question2txt.Anchor = AnchorStyles.Top;
            Question2txt.BorderStyle = BorderStyle.None;
            Question2txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question2txt.Location = new Point(317, 152);
            Question2txt.Name = "Question2txt";
            Question2txt.Size = new Size(219, 108);
            Question2txt.TabIndex = 94;
            Question2txt.Text = "";
            // 
            // QuestionTextLabel2
            // 
            QuestionTextLabel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel2.AutoSize = true;
            QuestionTextLabel2.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel2.Location = new Point(317, 119);
            QuestionTextLabel2.MaximumSize = new Size(0, 30);
            QuestionTextLabel2.MinimumSize = new Size(0, 30);
            QuestionTextLabel2.Name = "QuestionTextLabel2";
            QuestionTextLabel2.Size = new Size(150, 30);
            QuestionTextLabel2.TabIndex = 93;
            QuestionTextLabel2.Text = "Question Text";
            // 
            // correctAnsLabel2
            // 
            correctAnsLabel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel2.AutoSize = true;
            correctAnsLabel2.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel2.Location = new Point(317, 273);
            correctAnsLabel2.MaximumSize = new Size(0, 30);
            correctAnsLabel2.MinimumSize = new Size(0, 30);
            correctAnsLabel2.Name = "correctAnsLabel2";
            correctAnsLabel2.Size = new Size(164, 30);
            correctAnsLabel2.TabIndex = 92;
            correctAnsLabel2.Text = "Correct answer";
            // 
            // studentAns2
            // 
            studentAns2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns2.BackColor = Color.White;
            studentAns2.BorderStyle = BorderStyle.None;
            studentAns2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns2.Location = new Point(316, 372);
            studentAns2.MaximumSize = new Size(250, 30);
            studentAns2.MinimumSize = new Size(250, 30);
            studentAns2.Name = "studentAns2";
            studentAns2.Size = new Size(250, 30);
            studentAns2.TabIndex = 89;
            // 
            // correctAns2
            // 
            correctAns2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns2.BackColor = Color.White;
            correctAns2.BorderStyle = BorderStyle.None;
            correctAns2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns2.Location = new Point(317, 306);
            correctAns2.MaximumSize = new Size(250, 30);
            correctAns2.MinimumSize = new Size(250, 30);
            correctAns2.Name = "correctAns2";
            correctAns2.Size = new Size(250, 30);
            correctAns2.TabIndex = 90;
            // 
            // yourAnsLabel2
            // 
            yourAnsLabel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel2.AutoSize = true;
            yourAnsLabel2.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel2.Location = new Point(316, 339);
            yourAnsLabel2.MaximumSize = new Size(0, 30);
            yourAnsLabel2.MinimumSize = new Size(0, 30);
            yourAnsLabel2.Name = "yourAnsLabel2";
            yourAnsLabel2.Size = new Size(136, 30);
            yourAnsLabel2.TabIndex = 91;
            yourAnsLabel2.Text = "Your answer";
            // 
            // Question1txt
            // 
            Question1txt.Anchor = AnchorStyles.Top;
            Question1txt.BorderStyle = BorderStyle.None;
            Question1txt.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Question1txt.Location = new Point(23, 152);
            Question1txt.Name = "Question1txt";
            Question1txt.Size = new Size(219, 108);
            Question1txt.TabIndex = 88;
            Question1txt.Text = "";
            // 
            // QuestionTextLabel1
            // 
            QuestionTextLabel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            QuestionTextLabel1.AutoSize = true;
            QuestionTextLabel1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuestionTextLabel1.Location = new Point(23, 119);
            QuestionTextLabel1.MaximumSize = new Size(0, 30);
            QuestionTextLabel1.MinimumSize = new Size(0, 30);
            QuestionTextLabel1.Name = "QuestionTextLabel1";
            QuestionTextLabel1.Size = new Size(150, 30);
            QuestionTextLabel1.TabIndex = 87;
            QuestionTextLabel1.Text = "Question Text";
            // 
            // ShowGrievance
            // 
            ShowGrievance.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            ShowGrievance.BackColor = Color.FromArgb(174, 37, 43);
            ShowGrievance.FlatStyle = FlatStyle.Flat;
            ShowGrievance.Font = new Font("Candara", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ShowGrievance.ForeColor = Color.White;
            ShowGrievance.Location = new Point(591, 52);
            ShowGrievance.Name = "ShowGrievance";
            ShowGrievance.Size = new Size(97, 40);
            ShowGrievance.TabIndex = 86;
            ShowGrievance.Text = "Show";
            ShowGrievance.UseVisualStyleBackColor = false;
            ShowGrievance.Click += ShowGrievance_Click;
            // 
            // CourseComboBox
            // 
            CourseComboBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            CourseComboBox.FlatStyle = FlatStyle.Flat;
            CourseComboBox.Font = new Font("Candara", 10.8F);
            CourseComboBox.FormattingEnabled = true;
            CourseComboBox.Location = new Point(317, 59);
            CourseComboBox.MaximumSize = new Size(250, 0);
            CourseComboBox.MinimumSize = new Size(250, 0);
            CourseComboBox.Name = "CourseComboBox";
            CourseComboBox.Size = new Size(250, 30);
            CourseComboBox.TabIndex = 83;
            // 
            // CourseName
            // 
            CourseName.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            CourseName.AutoSize = true;
            CourseName.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CourseName.Location = new Point(230, 57);
            CourseName.MaximumSize = new Size(0, 30);
            CourseName.MinimumSize = new Size(0, 30);
            CourseName.Name = "CourseName";
            CourseName.Size = new Size(81, 30);
            CourseName.TabIndex = 82;
            CourseName.Text = "Course";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(174, 37, 43);
            label1.Location = new Point(348, 10);
            label1.MaximumSize = new Size(0, 50);
            label1.MinimumSize = new Size(0, 50);
            label1.Name = "label1";
            label1.Size = new Size(176, 50);
            label1.TabIndex = 81;
            label1.Text = "Grievance";
            // 
            // correctAnsLabel1
            // 
            correctAnsLabel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAnsLabel1.AutoSize = true;
            correctAnsLabel1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            correctAnsLabel1.Location = new Point(23, 273);
            correctAnsLabel1.MaximumSize = new Size(0, 30);
            correctAnsLabel1.MinimumSize = new Size(0, 30);
            correctAnsLabel1.Name = "correctAnsLabel1";
            correctAnsLabel1.Size = new Size(164, 30);
            correctAnsLabel1.TabIndex = 74;
            correctAnsLabel1.Text = "Correct answer";
            correctAnsLabel1.Click += label2_Click;
            // 
            // studentAns1
            // 
            studentAns1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            studentAns1.BackColor = Color.White;
            studentAns1.BorderStyle = BorderStyle.None;
            studentAns1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            studentAns1.Location = new Point(23, 372);
            studentAns1.MaximumSize = new Size(250, 30);
            studentAns1.MinimumSize = new Size(250, 30);
            studentAns1.Name = "studentAns1";
            studentAns1.Size = new Size(250, 30);
            studentAns1.TabIndex = 67;
            // 
            // correctAns1
            // 
            correctAns1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            correctAns1.BackColor = Color.White;
            correctAns1.BorderStyle = BorderStyle.None;
            correctAns1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            correctAns1.Location = new Point(23, 306);
            correctAns1.MaximumSize = new Size(250, 30);
            correctAns1.MinimumSize = new Size(250, 30);
            correctAns1.Name = "correctAns1";
            correctAns1.Size = new Size(250, 30);
            correctAns1.TabIndex = 69;
            // 
            // yourAnsLabel1
            // 
            yourAnsLabel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            yourAnsLabel1.AutoSize = true;
            yourAnsLabel1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            yourAnsLabel1.Location = new Point(23, 339);
            yourAnsLabel1.MaximumSize = new Size(0, 30);
            yourAnsLabel1.MinimumSize = new Size(0, 30);
            yourAnsLabel1.Name = "yourAnsLabel1";
            yourAnsLabel1.Size = new Size(136, 30);
            yourAnsLabel1.TabIndex = 73;
            yourAnsLabel1.Text = "Your answer";
            // 
            // GrievancePanel
            // 
            GrievancePanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            GrievancePanel.Controls.Add(Title);
            GrievancePanel.Location = new Point(0, 0);
            GrievancePanel.Name = "GrievancePanel";
            GrievancePanel.Size = new Size(930, 1500);
            GrievancePanel.TabIndex = 0;
            // 
            // Title
            // 
            Title.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            Title.AutoSize = true;
            Title.Font = new Font("Candara", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Title.ForeColor = Color.FromArgb(174, 37, 43);
            Title.Location = new Point(363, 24);
            Title.MaximumSize = new Size(0, 50);
            Title.MinimumSize = new Size(0, 50);
            Title.Name = "Title";
            Title.Size = new Size(203, 50);
            Title.TabIndex = 35;
            Title.Text = "GRIEVANCE";
            // 
            // Grievance
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Grievance";
            Size = new Size(930, 1339);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            GrievancePanel.ResumeLayout(false);
            GrievancePanel.PerformLayout();
            ResumeLayout(false);
        }



        #endregion

        private Panel panel1;
        private Label label1;
        private Label correctAnsLabel1;
        private TextBox studentAns1;
        private TextBox correctAns1;
        private Label yourAnsLabel1;
        private Button ShowGrievance;
        private ComboBox CourseComboBox;
        private Label CourseName;
        private RichTextBox Question1txt;
        private Label QuestionTextLabel1;
        private RichTextBox Question2txt;
        private Label QuestionTextLabel2;
        private Label correctAnsLabel2;
        private TextBox studentAns2;
        private TextBox correctAns2;
        private Label yourAnsLabel2;
        private RichTextBox Question6txt;
        private Label QuestionTextLabel6;
        private Label correctAnsLabel6;
        private TextBox studentAns6;
        private TextBox correctAns6;
        private Label yourAnsLabel6;
        private RichTextBox Question3txt;
        private Label QuestionTextLabel3;
        private Label correctAnsLabel3;
        private TextBox studentAns3;
        private TextBox correctAns3;
        private Label yourAnsLabel3;
        private RichTextBox Question5txt;
        private Label QuestionTextLabel5;
        private Label correctAnsLabel5;
        private TextBox studentAns5;
        private TextBox correctAns5;
        private Label yourAnsLabel5;
        private RichTextBox Question4txt;
        private Label QuestionTextLabel4;
        private Label correctAnsLabel4;
        private TextBox studentAns4;
        private TextBox correctAns4;
        private Label yourAnsLabel4;
        private Panel GrievancePanel;
        private Label Title;
        private RichTextBox Question9txt;
        private Label QuestionTextLabel9;
        private Label correctAnsLabel9;
        private TextBox studentAns9;
        private TextBox correctAns9;
        private Label yourAnsLabel9;
        private RichTextBox Question8txt;
        private Label QuestionTextLabel8;
        private Label correctAnsLabel8;
        private TextBox studentAns8;
        private TextBox correctAns8;
        private Label yourAnsLabel8;
        private RichTextBox Question7txt;
        private Label QuestionTextLabel7;
        private Label correctAnsLabel7;
        private TextBox studentAns7;
        private TextBox correctAns7;
        private Label yourAnsLabel7;
        private RichTextBox Question10txt;
        private Label QuestionTextLabel10;
        private Label correctAnsLabel10;
        private TextBox studentAns10;
        private TextBox correctAns10;
        private Label yourAnsLabel10;
    }
}
