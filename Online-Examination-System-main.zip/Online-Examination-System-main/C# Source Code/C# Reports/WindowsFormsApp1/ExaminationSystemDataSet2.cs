﻿namespace WindowsFormsApp1
{


    partial class ExaminationSystemDataSet2
    {
    }
}
